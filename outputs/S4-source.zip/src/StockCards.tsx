export { default } from "./InventoryCards";
